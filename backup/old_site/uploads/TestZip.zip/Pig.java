import java.util.Scanner;

public class Pig {

	public static int PlayerTurn() {
		Scanner userInput = new Scanner(System.in);
		int i = 0;
		int rand = 0;
		int turnScore = 0;
		boolean roll = true;
		String userChoice = "";
		
		while (roll == true) {

			rand = (int)(Math.random()*6+1);

			if (rand==1) {
				System.out.println("Sorry, you got a 1, your turn is over!");
				return 0;
				ComputerTurn();
			}

			System.out.println("Random number is " + rand);
			System.out.println("Would you like another roll (y/n)?");
			userChoice = userInput.nextLine();

		//.equalsIgnoreCase ignores string case

			if (userChoice.equalsIgnoreCase("y")) {
				roll=true;
				turnScore += rand;

			} else if (userChoice.equalsIgnoreCase("n")) {
				roll = false;

						//ending the turn

				System.out.print("*** Your score for the turn was " + turnScore);
				System.out.println(" ***");
				return turnScore;
			} else {
				System.out.println("Invalid input");
			}
		}

		return 0;
	}


	public static int ComputerTurn() {

		int randComp = 0;
		int turnScoreComp = 0;

		for (int i=1; i<=3; i++) {

			if (randComp == 1) {
				rolledZero = true;
				System.out.println ("OH SNAP! The computer rolled a 1.");
				turnScoreComp = 0;
				return 0;
				PlayerTurn();
			}
			else {

				randComp = (int)(Math.random()*6+1);
				turnscoreComp += randcomp;

			}
		}
		System.out.print("*** Your score for the turn was " + turnScoreComp);
		System.out.println(" ***")
		return 0;
		PlayerTurn();
	}


	public static void main (String[] args) {
		int totalPlayerScore = 0;
		int totalComputerScore = 0;
		System.out.println("Testing one round of a turn");

		while (totalPlayerScore<100 && totalComputerScore<100) {

			totalPlayerScore = totalPlayerScore + PlayerTurn();
			totalComputerScore = totalComputerScore + ComputerTurn();
		}


	}
}